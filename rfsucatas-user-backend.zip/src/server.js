require("dotenv").config();

const express = require("express");
const cors = require("cors");
const http = require("http");
const { Server } = require("socket.io");
const { PrismaClient } = require("@prisma/client");

const prisma = new PrismaClient();

const app = express();
app.use(cors());
app.use(express.json());

const API_KEY = process.env.API_KEY;

function authMiddleware(req, res, next) {
  const key = req.headers["x-api-key"];
  if (!API_KEY) return res.status(500).json({ ok: false, error: "API_KEY not configured" });
  if (!key || key !== API_KEY) return res.status(401).json({ ok: false, error: "Unauthorized" });
  next();
}

app.get("/", (req, res) => {
  res.json({ ok: true, name: "rfsucatas-user-api", status: "online" });
});

app.use(authMiddleware);

// CLIENTES
app.get("/clientes", async (req, res) => {
  const clientes = await prisma.cliente.findMany({ orderBy: { id: "desc" } });
  res.json({ ok: true, clientes });
});

app.post("/clientes", async (req, res) => {
  const { nome } = req.body;
  if (!nome) return res.status(400).json({ ok: false, error: "nome is required" });

  const cliente = await prisma.cliente.create({ data: { nome } });
  res.json({ ok: true, cliente });
});

// MATERIAIS
app.get("/materiais", async (req, res) => {
  const materiais = await prisma.material.findMany({ orderBy: { id: "desc" } });
  res.json({ ok: true, materiais });
});

app.post("/materiais", async (req, res) => {
  const { nome, preco } = req.body;
  if (!nome) return res.status(400).json({ ok: false, error: "nome is required" });
  if (preco === undefined || preco === null) return res.status(400).json({ ok: false, error: "preco is required" });

  const material = await prisma.material.create({
    data: { nome, preco: Number(preco) }
  });

  res.json({ ok: true, material });
});

// PESAGENS
app.get("/pesagens", async (req, res) => {
  const pesagens = await prisma.pesagem.findMany({
    include: { cliente: true, material: true },
    orderBy: { id: "desc" }
  });
  res.json({ ok: true, pesagens });
});

app.post("/pesagens", async (req, res) => {
  const { cliente_id, material_id, peso } = req.body;

  if (!cliente_id) return res.status(400).json({ ok: false, error: "cliente_id is required" });
  if (!material_id) return res.status(400).json({ ok: false, error: "material_id is required" });
  if (peso === undefined || peso === null) return res.status(400).json({ ok: false, error: "peso is required" });

  const material = await prisma.material.findUnique({
    where: { id: Number(material_id) }
  });

  if (!material) return res.status(404).json({ ok: false, error: "Material not found" });

  const valor = Number(peso) * Number(material.preco);

  const pesagem = await prisma.pesagem.create({
    data: {
      clienteId: Number(cliente_id),
      materialId: Number(material_id),
      peso: Number(peso),
      valor: Number(valor)
    },
    include: { cliente: true, material: true }
  });

  io.emit("nova_pesagem", pesagem);

  res.json({ ok: true, pesagem });
});

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

io.on("connection", (socket) => {
  console.log("Socket connected:", socket.id);
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log("RF Sucatas API running on port", PORT);
});